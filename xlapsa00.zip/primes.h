/*
primes.h
Riesenie IJC-DU1, priklad a), 14.3.2017
Autor: Tomas Lapsansky(xlapsa00), FIT VUT Brno
Prekladac: GCC 5.4.0
----------------------------------------------
Hlavickovy subor pre primes.h
*/

#include "bit_array.h"

void Eratosthenes(bit_array_t pole);
